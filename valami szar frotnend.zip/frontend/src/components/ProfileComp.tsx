import React from 'react'

const ProfileComp = () => {
  return (
    <>
    </>
  )
}

export default ProfileComp