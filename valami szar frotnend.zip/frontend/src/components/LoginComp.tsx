import React from 'react'

const LoginComp = () => {
  return (
    <div>LoginComp</div>
  )
}

export default LoginComp