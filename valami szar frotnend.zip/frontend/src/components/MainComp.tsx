import "./MainComp.css"

const MainComp = () => {

  return (
    <>
      <section className="search">
        <h1>Üdv a BudgetChef-en</h1>
        <input placeholder="Mit főzzek ma?" />
        <button>Népszerű receptek</button>
      </section>


      <section className="hero">
        <h2>Ínycsiklandó receptek minden napra!</h2>
        <button>Fedezd fel a recepteket</button>
      </section>


      <section className="popular">
        <h3>Népszerű receptek</h3>

        <div className="cards">
          <div className="card">Csirkepaprikás</div>
          <div className="card">Epres Tiramisu</div>
          <div className="card">Grillezett Lazac</div>
        </div>
      </section>


      <section className="categories">
        <h3>Kategóriák</h3>

        <div className="category-grid">
          <div>🍲 Főételek</div>
          <div>🍰 Desszertek</div>
          <div>🥦 Vegetáriánus</div>
          <div>⚡ Gyors & Könnyű</div>
        </div>
      </section>
    </>
  )
}

export default MainComp