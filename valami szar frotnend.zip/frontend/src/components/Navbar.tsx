import "./Navbar.css"


const Navbar = () => {
  return (
    <>
      <header className="navbar">
        <div className="branding">
          <img className="brandIconLeft" src="/img/wheat.png" alt="Logo ikon" />
          <div className="brandText">BudgetChef</div>
          <img className="brandIconRight" src="/img/wheat.png" alt="Logo ikon" />
        </div>

        <nav className="nav-links">
          <div className="dropdown">
            <span>Receptjeim ▾</span>

            <div className="dropdown-menu">
              <p>Saját receptek</p>
              <p>Új recept hozzáadása</p>
            </div>
          </div>

          <div className="dropdown">
            <span>Kategóriák ▾</span>

            <div className="dropdown-menu">
              <p>Főételek</p>
              <p>Desszertek</p>
              <p>Vegetáriánus</p>
            </div>
          </div>

          <span>Kedvencek</span>
        </nav>

        <div className="profile-pic">
          <p>Profil</p>
          <img src="/profile.png" alt="Profil" />
        </div>

      </header>
    </>
  );
};

export default Navbar;