import { PrismaClient, RecipeStatus } from "@prisma/client";
import { homeRecipes } from "../../src/seed/recipes.seed";
import { PrismaService } from "../../src/prisma/prisma.service";

const prisma = new PrismaService();

async function main() {
  const demoEmail = "demo@demo.hu";

  const user = await prisma.user.upsert({
    where: { email: demoEmail },
    update: {},
    create: {
      email: demoEmail,
      username: "Demo User",
      favorites: JSON.stringify(["Főétel", "Desszert"])
    },
  });

  for (const r of homeRecipes) {
  await prisma.recipe.create({
    data: {
      title: r.title,
      description: r.description,
      ingredients: r.ingredients,
      steps: r.steps,
      price: r.price,
      imageUrl: r.imageUrl,
      allergens: r.allergens,
      rating: r.rating,
      status: RecipeStatus.APPROVED, // <-- itt
      userId: user.id,
    },
  });
}
}
main()
  .then(async () => prisma.$disconnect())
  .catch(async (e) => {
    console.error(e);
    await prisma.$disconnect();
    process.exit(1);
  });