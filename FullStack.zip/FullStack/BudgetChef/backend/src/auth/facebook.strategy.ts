import { Injectable } from '@nestjs/common';
import { PassportStrategy } from '@nestjs/passport';
import { Strategy } from 'passport-facebook';

@Injectable()
export class FacebookStrategy extends PassportStrategy(Strategy, 'facebook') {
  constructor() {
    console.log("FB_APP_ID:", process.env.FACEBOOK_APP_ID);
    super({
      clientID: process.env.FACEBOOK_APP_ID!,
      clientSecret: process.env.FACEBOOK_APP_SECRET!,
      callbackURL: process.env.FACEBOOK_CALLBACK_URL!,
      profileFields: ['id', 'displayName', 'emails'],
      scope: ['email'],
    });
  }

  async validate(_: string, __: string, profile: any, done: any) {
    const email = profile?.emails?.[0]?.value; // FB-nél néha nincs
    const name = profile?.displayName ?? 'Facebook user';
    const providerId = profile?.id;

    done(null, { email, name, provider: 'facebook', providerId });
  }
}