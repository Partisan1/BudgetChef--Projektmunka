import { Controller, Get, Req, Res, UseGuards } from '@nestjs/common';
import { AuthGuard } from '@nestjs/passport';
import { AuthService } from './auth.service';
import { JwtAuthGuard } from './jwt-auth.guard';

@Controller('auth')
export class AuthController {
  constructor(private readonly auth: AuthService) {}

  @Get('google')
  @UseGuards(AuthGuard('google'))
  google() {}

  @Get('google/callback')
  @UseGuards(AuthGuard('google'))
  async googleCb(@Req() req: any, @Res() res: any) {
    const user = await this.auth.upsertOAuthUser(req.user);
    const token = this.auth.signAccessToken({ id: user.id, email: user.email, isAdmin: (user as any).isAdmin });

    res.cookie('access_token', token, {
      httpOnly: true,
      sameSite: 'lax',
      secure: false, // localhoston false, élesben true (https)
      maxAge: 15 * 60 * 1000,
    });

    return res.redirect(process.env.FRONTEND_URL ?? 'http://localhost:5173');
  }

  @Get('facebook')
  @UseGuards(AuthGuard('facebook'))
  facebook() {}

  @Get('facebook/callback')
  @UseGuards(AuthGuard('facebook'))
  async facebookCb(@Req() req: any, @Res() res: any) {
    const user = await this.auth.upsertOAuthUser(req.user);
    const token = this.auth.signAccessToken({ id: user.id, email: user.email, isAdmin: (user as any).isAdmin });

    res.cookie('access_token', token, {
      httpOnly: true,
      sameSite: 'lax',
      secure: false,
      maxAge: 15 * 60 * 1000,
    });

    return res.redirect(process.env.FRONTEND_URL ?? 'http://localhost:5173');
  }

  @Get('me')
  @UseGuards(JwtAuthGuard)
  me(@Req() req: any) {
    return req.user;
  }

  @Get('logout')
logout(@Res() res: any) {
  res.clearCookie('access_token', {
    httpOnly: true,
    sameSite: 'lax',
    secure: false, 
    path: '/',    
  });
  return res.status(200).json({ ok: true });
}
}