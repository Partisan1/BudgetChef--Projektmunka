import { Injectable, UnauthorizedException } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { PrismaService } from '../prisma/prisma.service';

@Injectable()
export class AuthService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly jwt: JwtService,
  ) {}

  async upsertOAuthUser(data: {
    email?: string;
    username?: string;   // <-- fontos
    name?: string;
    provider: string;
    providerId: string;
  }) {

    if (!data.email) {
      throw new UnauthorizedException('A szolgáltató nem adott vissza email címet.');
    }

    const username =
      data.username ??
      data.name ??
      (data.email ? data.email.split('@')[0] : 'User');

    return this.prisma.user.upsert({
      where: { email: data.email },
      update: {
        username,
        provider: data.provider,
        providerId: data.providerId,
      },
      create: {
        email: data.email,
        username,
        favorites: "[]",
        provider: data.provider,
        providerId: data.providerId,
        password: null,
        isAdmin: false,
      },
    });
  }

  signAccessToken(user: { id: number; email: string; isAdmin?: boolean }) {
    return this.jwt.sign(
      {
        sub: user.id,
        email: user.email,
        isAdmin: user.isAdmin ?? false,
      },
      {
        secret: process.env.JWT_SECRET!,
        expiresIn: "1d",
      },
    );
  }
}