// recipes.seed.ts (részlet)
export const homeRecipes = [
  {
    title: "Krémes paradicsomleves pirított kenyérkockával",
    description: "Gyors, olcsó, klasszikus paradicsomleves tejszínnel. 25 perc alatt kész.",
    ingredients:
      "1 ek olaj\n1 fej vöröshagyma\n2 gerezd fokhagyma\n500 ml passzírozott paradicsom\n400 ml víz vagy alaplé\n1 tk cukor\n1 tk só\n1/2 tk bors\n1 tk oregánó\n100 ml főzőtejszín\nKenyérkocka: 2 szelet kenyér + 1 ek olaj",
    steps:
      "1) Hagymát üvegesre párolod.\n2) Hozzáadod a fokhagymát, majd a paradicsomot.\n3) Felöntöd, fűszerezed, 15 percig főzöd.\n4) Tejszínt belekevered, 2 perc rotyog.\n5) Kenyérkockát pirítasz és tálalsz.",
    price: 700,
    imageUrl: "https://images.unsplash.com/photo-1547592166-23ac45744acd?auto=format&fit=crop&w=1200&q=80",
    allergens: "Glutén, Tej",
    rating: 5,
    status: "APPROVED",
    userId: 1,
  },
  {
    title: "Csirkés-zöldséges serpenyős tészta",
    description: "Egyserpenyős vacsora csirkemellel, paprikával és tejszínes szósszal.",
    ingredients:
      "250 g tészta\n300 g csirkemell\n1 db kaliforniai paprika\n1 db cukkini\n1 fej vöröshagyma\n2 gerezd fokhagyma\n200 ml főzőtejszín\n1 ek olívaolaj\n1 tk só\n1/2 tk bors\n1 tk fűszerpaprika\nReszelt sajt (opcionális)",
    steps:
      "1) Tésztát kifőzöd.\n2) Csirkét kockázod, lepirítod.\n3) Zöldségeket hozzáadod, puhítod.\n4) Tejszínt ráöntöd, fűszerezed.\n5) Tésztával összeforgatod, tálalod.",
    price: 1600,
    imageUrl: "https://images.unsplash.com/photo-1529042410759-befb1204b468?auto=format&fit=crop&w=1200&q=80",
    allergens: "Glutén, Tej",
    rating: 4,
    status: "APPROVED",
    userId: 1,
  },
  {
    title: "Lencsefőzelék füstölt kolbásszal",
    description: "Tartalmas, pénztárcabarát lencsefőzelék klasszikus ízekkel.",
    ingredients:
      "300 g lencse\n1 db sárgarépa\n1 fej vöröshagyma\n2 gerezd fokhagyma\n2 db babérlevél\n1 tk só\n1/2 tk bors\n1 tk ecet\n1 ek liszt\n2 ek olaj\n400 ml víz/alaplé\n150 g füstölt kolbász",
    steps:
      "1) Lencsét átmosod (ha kell, áztatod).\n2) Hagymát párolod, hozzáadod a répát.\n3) Lencse + babér + felöntés, puhára főzöd.\n4) Lisztes rántással sűríted.\n5) Ecettel ízesíted, kolbásszal tálalod.",
    price: 1400,
    imageUrl: "https://images.unsplash.com/photo-1604908177522-402e1d30b0b7?auto=format&fit=crop&w=1200&q=80",
    allergens: "Glutén",
    rating: 5,
    status: "APPROVED",
    userId: 1,
  },
  {
    title: "Kakaós bögrés süti (mikróban)",
    description: "5 perces desszert: kevered, mikrózod, kész. Mentőöv édességre.",
    ingredients:
      "4 ek liszt\n2 ek cukor\n2 ek kakaópor\n1/2 tk sütőpor\n3 ek tej\n2 ek olaj\n1 db tojás\n1 csipet só\nCsoki darabok (opcionális)",
    steps:
      "1) Bögrében összekevered a szárazakat.\n2) Hozzáadod a nedveseket, simára kevered.\n3) Mikró: 60–90 mp (teljesítménytől függ).\n4) Pihenteted 1 percet, kanalazod.",
    price: 350,
    imageUrl: "https://images.unsplash.com/photo-1519681393784-d120267933ba?auto=format&fit=crop&w=1200&q=80",
    allergens: "Glutén, Tojás, Tej",
    rating: 4,
    status: "APPROVED",
    userId: 1,
  },
];