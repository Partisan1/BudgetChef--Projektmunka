import { Injectable, UnauthorizedException, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { CreateUserDto } from './user.dto';
import * as argon2 from 'argon2';
import { JwtService } from '@nestjs/jwt';

@Injectable()
export class UserService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly jwt: JwtService,
  ) {}

  async findAllUser() {
    return this.prisma.user.findMany({
      select: {
        id: true,
        username: true,
        email: true,
        isAdmin: true,
      },
    });
  }

  async createUser(newUser: CreateUserDto) {
    if (!newUser.password) {
      throw new UnauthorizedException('A jelszó megadása kötelező.');
    }

    const passwordHash = await argon2.hash(newUser.password);

    return this.prisma.user.create({
      data: {
        ...newUser,
        password: passwordHash,
      },
      select: {
        id: true,
        username: true,
        email: true,
        isAdmin: true,
      },
    });
  }

  async loginUser(email: string, password: string) {
    const user = await this.prisma.user.findUnique({ where: { email } });

    console.log("JwtService exists:", !!this.jwt);
    console.log("JWT_SECRET in service:", process.env.JWT_SECRET);

    if (!user) {
      throw new UnauthorizedException('Hibás email vagy jelszó!');
    }

    if (!user.password) {
      throw new UnauthorizedException('Hibás email vagy jelszó!');
    }

    const ok = await argon2.verify(user.password, password);
    if (!ok) {
      throw new UnauthorizedException('Hibás email vagy jelszó!');
    }

    const access_token = this.jwt.sign(
  { sub: user.id, email: user.email, isAdmin: user.isAdmin ?? false },
  { secret: process.env.JWT_SECRET! , expiresIn: "1d" }
);

    const { password: _pw, ...safe } = user;

    return {
      access_token,
      user: safe,
    };
  }

  async removeUser(id: number) {
    const exists = await this.prisma.user.findUnique({ where: { id } });
    if (!exists) throw new NotFoundException('Nem található a felhasználó!');

    return this.prisma.user.delete({
      where: { id },
      select: { id: true },
    });
  }
  async getProfile(userId: number) {
  return this.prisma.user.findUnique({
    where: { id: userId },
    select: {
      id: true,
      username: true,
      email: true,
      isAdmin: true,
      favorites: true,
      recipes: {
        select: {
          id: true,
          title: true,
          status: true,
          createdAt: true,
          imageUrl: true,
          rating: true,
        },
      },
      comments: {
        select: {
          id: true,
          content: true,
          rating: true,
          recipe: {
            select: { id: true, title: true },
          },
        },
      },
    },
  });
}
}
