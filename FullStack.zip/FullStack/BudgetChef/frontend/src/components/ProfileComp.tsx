import React, { useEffect, useMemo, useState, type JSX } from "react";
import {
  Alert,
  Badge,
  Button,
  Card,
  Col,
  Container,
  ListGroup,
  Row,
  Spinner,
} from "react-bootstrap";
import "./ProfileComp.css"
const API_BASE = "http://localhost:3001"; // backend host:port

type RecipeStatus = "PENDING" | "APPROVED" | "REJECTED";

type Recipe = {
  id: number;
  title: string;
  status: RecipeStatus;
  createdAt?: string | Date;
  imageUrl?: string | null;
  rating?: number | null;
};

type Comment = {
  id: number;
  content: string;
  rating: number;
  recipe?: {
    id: number;
    title: string;
  } | null;
};

type Profile = {
  id: number;
  username: string;
  email: string;
  isAdmin: boolean;
  favorites?: string | null;
  provider?: string | null;
  providerId?: string | null;
  recipes?: Recipe[];
  comments?: Comment[];
};

function parseFavorites(favorites?: string | null): string[] {
  if (!favorites) return [];
  try {
    const parsed = JSON.parse(favorites);
    if (Array.isArray(parsed)) return parsed.map((x) => String(x));
  } catch {}
  return favorites
    .split(",")
    .map((s) => s.trim())
    .filter(Boolean);
}

function statusVariant(status: RecipeStatus): string {
  switch (status) {
    case "APPROVED":
      return "success";
    case "REJECTED":
      return "danger";
    case "PENDING":
    default:
      return "warning";
  }
}

function formatDate(value?: string | Date): string {
  if (!value) return "—";
  const d = typeof value === "string" ? new Date(value) : value;
  if (Number.isNaN(d.getTime())) return "—";
  return d.toLocaleString();
}

export default function ProfileComp(): JSX.Element {
  const [profile, setProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [err, setErr] = useState<string>("");

  const loadProfile = async (): Promise<void> => {
  setLoading(true);
  setErr("");

  try {
    const token = localStorage.getItem("token");
    const url = new URL("/api/user/profile", API_BASE).toString();

    const res = await fetch(url, {
      credentials: "include",
      headers: token && token !== "undefined"
        ? { Authorization: `Bearer ${token}` }
        : undefined,
    });

    if (!res.ok) {
      const text = await res.text().catch(() => "");
      throw new Error(`Hiba (${res.status}): ${text || res.statusText}`);
    }

    const data = (await res.json()) as Profile;
    setProfile(data);
  } catch (e) {
    const msg = e instanceof Error ? e.message : "Ismeretlen hiba a profil lekérésekor.";
    setErr(msg);
    setProfile(null);
  } finally {
    setLoading(false);
  }
};

  useEffect(() => {
    void loadProfile();
  }, []);

  const favoritesList = useMemo(
    () => parseFavorites(profile?.favorites),
    [profile?.favorites]
  );

  if (loading) {
  return (
    <div className="bc-profile-page">
      <Container className="bc-shell">
        <div className="d-flex align-items-center gap-2">
          <Spinner animation="border" size="sm" />
          <div>Profil betöltése…</div>
        </div>
      </Container>
    </div>
  );
}

  if (err) {
  return (
    <div className="bc-profile-page bc-alert">
      <Container className="bc-shell">
        <Alert variant="danger">
          <div className="d-flex justify-content-between align-items-center gap-3">
            <div>{err}</div>
            <Button className="bc-btn bc-btn-outline" size="sm" onClick={() => void loadProfile()}>
              Újrapróbálom
            </Button>
          </div>
        </Alert>
      </Container>
    </div>
  );
}

  if (!profile) {
  return (
    <div className="bc-profile-page bc-alert">
      <Container className="bc-shell">
        <Alert variant="warning">Nincs megjeleníthető profil adat.</Alert>
      </Container>
    </div>
  );
}

  return (
  <div className="bc-profile-page">
    <Container className="bc-shell">
      <Row className="g-3">
        <Col xs={12}>
          {/* HERO */}
          <Card className="bc-hero">
            <Card.Body>
              <div className="bc-row">
                <div className="bc-left">
                  <div className="bc-avatar">
                    {(profile.username?.[0] ?? "B").toUpperCase()}
                  </div>

                  <div className="bc-meta">
                    <h3 className="bc-title">BudgetChef Profil</h3>
                    <div className="bc-subtitle">{profile.email}</div>
                  </div>
                </div>

                <Button className="bc-btn bc-btn-outline" size="sm" onClick={() => void loadProfile()}>
                  Frissítés
                </Button>
              </div>

              <div className="bc-kv">
                <div>
                  <div className="k">Felhasználónév</div>
                  <div className="v">{profile.username}</div>
                </div>

                <div>
                  <div className="k">Szerepkör</div>
                  <div className="v">{profile.isAdmin ? "Admin" : "Felhasználó"}</div>
                </div>

                <div>
                  <div className="k">Belépés</div>
                  <div className="v">{profile.provider ? `${profile.provider} (OAuth)` : "jelszó"}</div>
                </div>
              </div>
            </Card.Body>
          </Card>
        </Col>

        <Col xs={12} md={4}>
          {/* Kedvencek */}
          <Card className="bc-card">
            <Card.Body>
              <Card.Title className="bc-section-title">Kedvenc ételek</Card.Title>

              {favoritesList.length === 0 ? (
                <div className="profile-empty">Nincs kedvenc megadva.</div>
              ) : (
                <div className="bc-chips">
                  {favoritesList.map((f, i) => (
                    <span className="bc-chip" key={`${f}-${i}`}>
                      {f}
                    </span>
                  ))}
                </div>
              )}
            </Card.Body>
          </Card>
        </Col>

        <Col xs={12} md={8}>
          {/* Receptek */}
          <Card className="bc-card">
            <Card.Body>
              <Card.Title className="bc-section-title">
                Feltöltött receptjeim
                <span className="bc-count">{profile.recipes?.length ?? 0}</span>
              </Card.Title>

              {!profile.recipes?.length ? (
                <div className="profile-empty">Még nem töltöttél fel receptet.</div>
              ) : (
                <ListGroup variant="flush" className="bc-list">
                  {profile.recipes.map((r) => (
                    <ListGroup.Item key={r.id}>
                      <div className="bc-item">
                        <div className="left">
                          <div className="bc-item-title">{r.title}</div>
                          <div className="bc-item-sub">Létrehozva: {formatDate(r.createdAt)}</div>
                          <div className="bc-item-sub">
                            Értékelés: {typeof r.rating === "number" ? r.rating : "—"}
                          </div>
                        </div>

                        <div className="bc-right">
                          <span className={`bc-pill ${r.status.toLowerCase()}`}>
                            {r.status}
                          </span>

                          {r.imageUrl ? (
                            <a className="bc-link" href={r.imageUrl} target="_blank" rel="noreferrer">
                              Kép megnyitása
                            </a>
                          ) : (
                            <span className="bc-item-sub">Nincs kép</span>
                          )}
                        </div>
                      </div>
                    </ListGroup.Item>
                  ))}
                </ListGroup>
              )}
            </Card.Body>
          </Card>

          {/* Kommentek */}
          <Card className="bc-card mt-3">
            <Card.Body>
              <Card.Title className="bc-section-title">
                Kommentjeim
                <span className="bc-count">{profile.comments?.length ?? 0}</span>
              </Card.Title>

              {!profile.comments?.length ? (
                <div className="profile-empty">Még nem írtál kommentet.</div>
              ) : (
                <ListGroup variant="flush" className="bc-list">
                  {profile.comments.map((c) => (
                    <ListGroup.Item key={c.id}>
                      <div className="bc-item">
                        <div className="left">
                          <div className="bc-item-title">
                            Recept: {c.recipe?.title ?? "—"}
                          </div>
                          <div className="bc-item-sub">{c.content}</div>
                        </div>

                        <div className="bc-right">
                          <span className="bc-pill approved">⭐ {c.rating}</span>
                          {c.recipe?.id ? (
                            <span className="bc-item-sub">Recipe ID: {c.recipe.id}</span>
                          ) : null}
                        </div>
                      </div>
                    </ListGroup.Item>
                  ))}
                </ListGroup>
              )}
            </Card.Body>
          </Card>
        </Col>
      </Row>
    </Container>
  </div>
);
}