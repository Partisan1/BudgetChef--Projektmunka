import React from 'react'

const AdminComp = () => {
  return (
    <div>AdminComp</div>
  )
}

export default AdminComp