import { useEffect, useState } from "react";
import { Container, Row, Col, Card, Badge, Spinner, Alert } from "react-bootstrap";
import { fetchMe } from "../lib/auth";
import { fetchHomeRecipes } from "../lib/recipes";



export default function MainComp() {
  

  return (
    <div>Rémisztő</div>
  );
}