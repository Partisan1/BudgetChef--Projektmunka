import { Link, useNavigate } from "react-router-dom";
import api from "../lib/app";

const Navbar = () => {
  const navigate = useNavigate();

  const handleLogout = async () => {
    try {
      await api.get("/auth/logout");
    } catch (e) {
    }

    localStorage.removeItem("token");
    localStorage.removeItem("user");

    navigate("/login", { replace: true });
  };

  return (
    <nav style={styles.nav}>
      <h2 style={styles.logo}>🍲 RecipeApp</h2>

      <ul style={styles.ul}>
        <li><Link to="/" style={styles.link}>Főoldal</Link></li>
        <li><Link to="/recipes" style={styles.link}>Receptek</Link></li>
        <li><Link to="/soups" style={styles.link}>Levesek</Link></li>
        <li><Link to="/desserts" style={styles.link}>Desszertek</Link></li>
        <li><Link to="/favorites" style={styles.link}>Kedvencek</Link></li>
        <li><Link to="/profile" style={styles.link}>Profil</Link></li>
        <li>
          <button onClick={handleLogout} style={styles.button}>
            Kijelentkezés
          </button>
        </li>
      </ul>
    </nav>
  );
};

export default Navbar;

const styles = {
  nav: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    padding: "12px 24px",
    backgroundColor: "#222",
  },
  logo: {
    color: "white",
  },
  ul: {
    display: "flex",
    listStyle: "none",
    gap: "16px",
    alignItems: "center",
  },
  link: {
    color: "white",
    textDecoration: "none",
  },
  button: {
    padding: "6px 12px",
    cursor: "pointer",
  },
};
