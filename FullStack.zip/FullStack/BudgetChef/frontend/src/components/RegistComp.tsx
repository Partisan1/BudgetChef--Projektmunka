import React, { useMemo, useState, type FormEvent } from "react";
import { Alert, Button, Card, Container, Form, Spinner, ProgressBar } from "react-bootstrap";
import api from "../lib/app";
import "./RegistComp.css";
import logo from "../assets/budgetchef.png";
import { useNavigate } from "react-router-dom";

const FAVORITES = [
  "Leves",
  "Főétel",
  "Desszert",
  "Saláta",
  "Tészta",
  "Pizza",
  "Vegán",
  "Gluténmentes",
  "Laktózmentes",
];

function passwordScore(pw: string) {
  let score = 0;
  if (pw.length >= 6) score += 25;
  if (pw.length >= 10) score += 20;
  if (/[A-Z]/.test(pw)) score += 15;
  if (/[a-z]/.test(pw)) score += 10;
  if (/[0-9]/.test(pw)) score += 15;
  if (/[^A-Za-z0-9]/.test(pw)) score += 15;
  return Math.min(score, 100);
}

function scoreLabel(score: number) {
  if (score < 35) return "Gyenge";
  if (score < 65) return "Közepes";
  if (score < 85) return "Jó";
  return "Erős";
}

const RegistComp = () => {
  const [fullName, setFullName] = useState("");
  const [email, setEmail] = useState("");
  const [pw1, setPw1] = useState("");
  const [pw2, setPw2] = useState("");

  const [showPw1, setShowPw1] = useState(false);
  const [showPw2, setShowPw2] = useState(false);

  const [favorites, setFavorites] = useState<string[]>([]);

  const [loading, setLoading] = useState(false);
  const [socialLoading, setSocialLoading] = useState<"google" | "facebook" | null>(null);
  const [error, setError] = useState<string | null>(null);

  const navigate = useNavigate();

  const apiBase = import.meta.env.VITE_API_URL ?? "http://localhost:3001/api";

  const toggleFavorite = (name: string) => {
    setFavorites((prev) =>
      prev.includes(name) ? prev.filter((x) => x !== name) : [...prev, name]
    );
  };

  const pwScore = useMemo(() => passwordScore(pw1), [pw1]);

  const canSubmit = useMemo(() => {
    return (
      fullName.trim().length >= 2 &&
      email.trim().length >= 5 &&
      pw1.trim().length >= 6 &&
      pw1 === pw2 &&
      !loading &&
      !socialLoading
    );
  }, [fullName, email, pw1, pw2, loading, socialLoading]);

  const handleSocial = (provider: "google" | "facebook") => {
    setError(null);
    setSocialLoading(provider);
    window.location.href = `${apiBase}/auth/${provider}`;
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setError(null);

    if (pw1.length < 6) return setError("A jelszónak legalább 6 karakternek kell lennie.");
    if (pw1 !== pw2) return setError("A két jelszó nem egyezik.");
    const favsToSend = favorites.length ? favorites : ["Főétel"];

    setLoading(true);
    try {
      await api.post("/user/register", {
        username: fullName,
        email,
        password: pw1,
        favorites: JSON.stringify(favsToSend),
      });

      navigate("/login");
    } catch (err: any) {
      const msg = err?.response?.data?.message ?? "Sikertelen regisztráció";
      setError(Array.isArray(msg) ? msg.join(", ") : msg);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="reg-page">
      <Container className="reg-center">
        <Card className="reg-card">
          <Card.Body>
            <div className="reg-head">
              <div className="reg-logo-wrap">
                <img src={logo} alt="BudgetChef logo" className="reg-logo" />
              </div>

              <h1 className="reg-title">Ingyenes fiók létrehozása</h1>
              <p className="reg-subtitle">
                Készíts menütervet 2 perc alatt, kapj bevásárlólistát és költségbarát recepteket.
              </p>

              <div className="reg-badges">
                <span className="badge-pill">🥗 Menütervező</span>
                <span className="badge-pill">🧾 Lista</span>
                <span className="badge-pill">💸 Spórolás</span>
              </div>
            </div>

            {error && (
              <Alert variant="danger" className="mb-3">
                {error}
              </Alert>
            )}

            {/* Social login FELÜL */}
            <div className="reg-social-stack">
              <Button
                type="button"
                className="reg-social google"
                onClick={() => handleSocial("google")}
                disabled={loading || !!socialLoading}
              >
                <span className="icon g">G</span>
                {socialLoading === "google" ? "Átirányítás..." : "Regisztráció Google-lel"}
              </Button>

              <Button
                type="button"
                className="reg-social fb"
                onClick={() => handleSocial("facebook")}
                disabled={loading || !!socialLoading}
              >
                <span className="icon">f</span>
                {socialLoading === "facebook" ? "Átirányítás..." : "Regisztráció Facebookkal"}
              </Button>
            </div>

            <div className="reg-divider">
              <span>vagy emaillel</span>
            </div>

            <Form onSubmit={handleSubmit}>
              <Form.Control
                className="reg-input"
                placeholder="Teljes név"
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                autoComplete="name"
                required
              />

              <Form.Control
                className="reg-input"
                placeholder="Email cím"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                autoComplete="email"
                required
              />

              {/* Jelszó 1 */}
              <div className="pw-wrap">
                <Form.Control
                  className="reg-input pw-input"
                  placeholder="Jelszó (min. 6 karakter)"
                  type={showPw1 ? "text" : "password"}
                  value={pw1}
                  onChange={(e) => setPw1(e.target.value)}
                  autoComplete="new-password"
                  required
                />
                <button
                  type="button"
                  className="pw-toggle"
                  onClick={() => setShowPw1((s) => !s)}
                  aria-label={showPw1 ? "Jelszó elrejtése" : "Jelszó megjelenítése"}
                >
                  {showPw1 ? "🙈" : "👁️"}
                </button>
              </div>

              <div className="pw-meter">
                <div className="pw-meter-top">
                  <span className="pw-meter-label">Jelszó erőssége:</span>
                  <span className="pw-meter-value">{scoreLabel(pwScore)}</span>
                </div>
                <ProgressBar now={pwScore} className="pw-progress" />
              </div>

              {/* Jelszó 2 */}
              <div className="pw-wrap">
                <Form.Control
                  className="reg-input pw-input"
                  placeholder="Jelszó megerősítése"
                  type={showPw2 ? "text" : "password"}
                  value={pw2}
                  onChange={(e) => setPw2(e.target.value)}
                  autoComplete="new-password"
                  required
                />
                <button
                  type="button"
                  className="pw-toggle"
                  onClick={() => setShowPw2((s) => !s)}
                  aria-label={showPw2 ? "Jelszó elrejtése" : "Jelszó megjelenítése"}
                >
                  {showPw2 ? "🙈" : "👁️"}
                </button>
              </div>

              <Form.Group className="mb-3">
                <div className="fav-head">
                  <Form.Label className="fw-bold mb-0">Kedvencek</Form.Label>
                  <span className="fav-hint">Ajánlott (később módosítható)</span>
                </div>

                <div className="fav-wrap">
                  {FAVORITES.map((fav) => {
                    const active = favorites.includes(fav);
                    return (
                      <button
                        type="button"
                        key={fav}
                        onClick={() => toggleFavorite(fav)}
                        className={`fav-chip ${active ? "active" : ""}`}
                        aria-pressed={active}
                      >
                        {fav}
                      </button>
                    );
                  })}
                </div>
              </Form.Group>

              <Button type="submit" className="reg-btn" disabled={!canSubmit}>
                {loading ? (
                  <>
                    <Spinner size="sm" className="me-2" />
                    Fiók létrehozása...
                  </>
                ) : (
                  "Fiók létrehozása"
                )}
              </Button>

              <div className="reg-footer">
                Már van fiókod?{" "}
                <button
                  type="button"
                  className="reg-link-btn"
                  onClick={() => navigate("/login")}
                  disabled={loading || !!socialLoading}
                >
                  Bejelentkezés
                </button>
              </div>

              <div className="reg-legal">
                A regisztrációval elfogadod az <a href="/terms">ÁSZF</a>-et és az{" "}
                <a href="/privacy">Adatkezelést</a>.
              </div>
            </Form>
          </Card.Body>
        </Card>
      </Container>
    </div>
  );
};

export default RegistComp;
