import React from 'react'

const FavouritesComp = () => {
  return (
    <div>FavoritesComp</div>
  )
}

export default FavouritesComp