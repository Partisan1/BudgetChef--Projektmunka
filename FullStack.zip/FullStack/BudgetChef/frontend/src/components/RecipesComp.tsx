import React from 'react'
import { useEffect, useState } from "react";
import { Container, Row, Col, Card, Badge, Spinner, Alert } from "react-bootstrap";
import { fetchMe } from "../lib/auth";
import { fetchHomeRecipes } from "../lib/recipes";

type Recipe = {
  id: number;
  title: string;
  imageUrl: string;
  price: number;
  rating: number;
  description: string;
};

function normalizeRecipes(payload: any): Recipe[] {
  if (Array.isArray(payload)) return payload;
  if (Array.isArray(payload?.recipes)) return payload.recipes;
  if (Array.isArray(payload?.data)) return payload.data;
  return [];
}

const RecipesComp = () => {
  const [me, setMe] = useState<any>(null);
  const [recipes, setRecipes] = useState<Recipe[]>([]);
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState<string | null>(null);

  useEffect(() => {
    (async () => {
      try {
        // me nem kritikus, ha elhasal, csak null
        const meRes = await fetchMe().catch(() => null);
        setMe(meRes);

        const recipesRes = await fetchHomeRecipes();
        setRecipes(normalizeRecipes(recipesRes));
      } catch (e: any) {
        console.error(e);
        setErr(e?.response?.data?.message ?? "Nem sikerült betölteni a recepteket");
        setRecipes([]);
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  return (
    <Container className="mt-4">
      <div className="d-flex justify-content-between align-items-center mb-3">
        <h4 className="mb-0">Receptek tárháza</h4>
        {me ? (
          <Badge bg="success">Belépve: {me.email}</Badge>
        ) : (
          <Badge bg="secondary">Nincs belépve</Badge>
        )}
      </div>

      {loading && (
        <div className="d-flex justify-content-center py-5">
          <Spinner animation="border" />
        </div>
      )}

      {!loading && err && <Alert variant="danger">{err}</Alert>}

      {!loading && !err && recipes.length === 0 && (
        <Alert variant="info">Nincs recept, amit meg tudnék jeleníteni.</Alert>
      )}

      <Row>
        {recipes.map((recipe) => (
          <Col key={recipe.id} xs={12} sm={6} md={4} lg={3} className="mb-4">
            <Card className="h-100 shadow-sm">
              <Card.Img
                variant="top"
                src={recipe.imageUrl || "https://via.placeholder.com/600x400?text=No+Image"}
                style={{ height: 180, objectFit: "cover" }}
              />
              <Card.Body className="d-flex flex-column">
                <Card.Title className="mb-2">{recipe.title}</Card.Title>

                <Card.Text className="text-muted" style={{ fontSize: "0.9rem" }}>
                  {(recipe.description ?? "").slice(0, 80)}
                  {(recipe.description ?? "").length > 80 ? "..." : ""}
                </Card.Text>

                <div className="mt-auto d-flex justify-content-between align-items-center">
                  <Badge bg="success">{recipe.price} Ft</Badge>
                  <span>⭐ {recipe.rating}</span>
                </div>
              </Card.Body>
            </Card>
          </Col>
        ))}
      </Row>
    </Container>
  );
}

export default RecipesComp