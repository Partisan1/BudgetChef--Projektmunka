// src/lib/recipes.ts
import api from "./app";

export async function fetchHomeRecipes() {
  const res = await api.get("/recipes");
  return res.data;
}