import api from "./app";

export async function fetchMe() {
  try {
    const res = await api.get("/auth/me");
    return res.data;
  } catch (err: any) {
    if (err?.response?.status === 401 || err?.response?.status === 403) {
      return null;
    }
    throw err;
  }
}