import React from 'react'

const RecipeForm = () => {
  return (
    <div>RecipeForm</div>
  )
}

export default RecipeForm