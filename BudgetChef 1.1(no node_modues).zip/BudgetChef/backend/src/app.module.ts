import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { ConfigModule } from '@nestjs/config';
import { PrismaModule } from './prisma/prisma.module';
import { UserController } from './user/user.controller';
import { UserModule } from './user/user.module';
import { RecipeController } from './recipe/recipe.controller';
import { RecipeModule } from './recipe/recipe.module';
import { CommentController } from './comment/comment.controller';
import { CommentModule } from './comment/comment.module';
import "dotenv/config";

@Module({
  imports: [
    PrismaModule,
    UserModule,
    RecipeModule,
    CommentModule,
    ConfigModule.forRoot({isGlobal:true})
    ],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule {}