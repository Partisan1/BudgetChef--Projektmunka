import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { CreateUserDto } from './user.dto';
import { NotFoundException } from '@nestjs/common';

@Injectable()
export class UserService {
  constructor(private readonly prisma: PrismaService) {}

  async findAllUser() {
    return this.prisma.user.findMany({
      select: {
        id: true,
        username: true,
        email: true,
        password: true,
        isAdmin: true,
      },
    });
  }

  async createUser(newUser: CreateUserDto) {
    return this.prisma.user.create({
      data: newUser,
    });
  }

  async removeUser(id: number) {
    const exists = await this.prisma.user.findUnique({ where: { id } });
    if (!exists) {
      throw new NotFoundException('User not found!');
    }

    return this.prisma.user.delete({
      where: { id },
      select: { id: true },
    });
  }
}
