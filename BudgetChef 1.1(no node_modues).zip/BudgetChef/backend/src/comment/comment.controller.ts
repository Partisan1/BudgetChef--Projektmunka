import { Controller } from '@nestjs/common';

@Controller('comment')
export class CommentController {}
