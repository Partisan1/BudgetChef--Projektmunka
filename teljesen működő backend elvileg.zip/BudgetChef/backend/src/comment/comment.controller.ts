import { Body, Controller, Delete, Get, Param, ParseIntPipe, Post, Request } from '@nestjs/common';
import { CommentService } from './comment.service';
import { CreateCommentDto } from './comment.dto';
import { Public } from '../auth/public.decorator';

@Controller('comment')
export class CommentController {
    constructor(private readonly service: CommentService){}
    @Public()
    @Get('recipes/:id/comments')
    async getCommentByRecipeId(@Param('id', ParseIntPipe) id: string){
        return this.service.getCommentById(Number(id));
    }

    @Post('recipes/:id/comments')
    async postCommentByRecipeId(
        @Param('id', ParseIntPipe) id: string,
        @Body() dto: CreateCommentDto,
        @Request() req
    ){
        const userId = req.user.id
        return this.service.postComment(Number(id), userId, dto.content, dto.rating);
    }

    @Delete(':id')
    async removeComment(@Param('id', ParseIntPipe) id: string){
        return await this.service.deleteComment(Number(id));
    }
}
