import { Body, Controller,UseInterceptors, BadRequestException, Delete, Get, Param, ParseIntPipe, Post, Put } from '@nestjs/common';
import { RecipeService } from './recipe.service';
import { CreateRecipeDto, UpdateRecipeDto } from './recipe.dto';
import { Public } from '../auth/public.decorator';
import { FileInterceptor } from '@nestjs/platform-express';
import { diskStorage } from 'multer';


function createValidName(imageName: string) {
    return imageName
        .replace(/\s+/g, '-')
        .replace(/[^a-zA-Z0-9._-]/g, '');
}

@Controller('recipes')
export class RecipeController {
    constructor(private readonly service: RecipeService) { }

    @Public()
    @Get()
    async getRecipes() {
        return await this.service.findAllRecipe();
    }

    @Public()
    @Get(":id")
    async getRecipeById(@Param("id", ParseIntPipe) id: number) {
        return await this.service.getRecipeById(id);
    }

    @Get('admin/recipe/pending')
    async getPendingRecipes() {
        return await this.service.findPENDINGRecipes();
    }

    @UseInterceptors(
        FileInterceptor('image', {
            storage: diskStorage({
                destination: './uploads',
                filename: (req, file, cb) => cb(null, createValidName(file.originalname))
            }),
            limits: { fileSize: 3 * 1024 * 1024 },
            fileFilter: (req, file, cb) => {
                if (!file.mimetype.startsWith('image/')) {
                    return cb(new BadRequestException('Csak képfájlok engedélyezettek.') as any, false)
                }
                cb(null, true);
            }
        }),

    )

    @Post("")
    async postRecipe(@Body() dto: CreateRecipeDto) {
        return await this.service.createRecipe(dto);
    }

    @Put(":id")
    async updateRecipe(@Param("id", ParseIntPipe,) id: number, @Body() dto: UpdateRecipeDto) {
        return await this.service.updateRecipe(id, dto);
    }

    @Delete(":id")
    async removeRecipe(@Param("id", ParseIntPipe) id: number) {
        return await this.service.deleteRecipe(id);
    }
}
