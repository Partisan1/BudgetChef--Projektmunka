import { Controller, Post, Body } from '@nestjs/common';
import { AuthService } from './auth.service';
import { LoginUserDto, RegisterUserDto } from './auth.dto';
import { Public } from './public.decorator';

@Public()
@Controller('auth')
export class AuthController {
    constructor(private readonly authService: AuthService) {}

    @Post('register')
    async register(@Body() user: RegisterUserDto) {
        return await this.authService.authRegister(user);
    }

    @Post('login')
    async login(@Body() user: LoginUserDto) {
        return await this.authService.authLogin(user);
    }
}
