-- AlterTable
ALTER TABLE `Recipe` MODIFY `imageUrl` VARCHAR(191) NULL;
