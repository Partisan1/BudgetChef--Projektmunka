import React from 'react'

const RecipesComp = () => {
  return (
    <div>RecipesComp</div>
  )
}

export default RecipesComp