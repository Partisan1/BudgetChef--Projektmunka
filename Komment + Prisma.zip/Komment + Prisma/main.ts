import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import cookieParser from "cookie-parser"
import 'dotenv/config';
import { BadRequestException, ValidationPipe } from '@nestjs/common';
console.log("JWT_SECRET in main:", process.env.JWT_SECRET);

async function bootstrap() {
  const app = await NestFactory.create(AppModule);

  app.use(cookieParser())

  app.enableCors({
    origin: 'http://localhost:5173',
    methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization'],
    credentials: true,
  });
  app.enableShutdownHooks();
  app.setGlobalPrefix('api');
  app.useGlobalPipes(new ValidationPipe({
    whitelist: true,
    transform: true,
    forbidNonWhitelisted: true,
    transformOptions: {enableImplicitConversion: true},
    exceptionFactory: () => {
      return new BadRequestException("Hiányzó adatok.");
    }
  }))
  await app.listen(process.env.PORT || 3000);
}
bootstrap();
