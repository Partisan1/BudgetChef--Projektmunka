import { IsNumber, IsString, Max, MaxLength } from "class-validator";

export class CreateCommentDto{
    userId!: number;
    recipeId!: number;

    @IsString()
    @MaxLength(100)
    content!:  string;

    @IsNumber()
    @Max(5)
    rating!: number;


}