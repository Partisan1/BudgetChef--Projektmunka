import { Body, Controller, Delete, Get, Param, ParseIntPipe, Post } from '@nestjs/common';
import { CommentService } from './comment.service';
import { CreateCommentDto } from './comment.dto';

@Controller('comment')
export class CommentController {
    constructor(private readonly service: CommentService){}

    @Get()
    async getComment(@Param(":id", ParseIntPipe) id: number){
        return await this.service.getCommentByRecipeId(id);
    }

    @Post()
    async postComment(@Body() body: CreateCommentDto){
        return await this.service.createComment(body);
    }

    @Delete()
    async deleteComment(@Param(":id", ParseIntPipe) id: number){
        return await this.service.removeComment(id);
    }
}
