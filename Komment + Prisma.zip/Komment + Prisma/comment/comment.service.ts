import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { CreateCommentDto } from './comment.dto';

@Injectable()
export class CommentService {
    constructor(private readonly prisma: PrismaService){}

    async getCommentByRecipeId(recipeId: number){
        const exists = await this.prisma.comment.findUnique({where: {id: recipeId}});
        if(!exists) throw new NotFoundException("Hiba: a comment nem található!");
        return await this.prisma.comment.findUnique({where: {id: recipeId}});
    }

    async createComment(dto: CreateCommentDto){
        return await this.prisma.comment.create({data: dto});
    }

    async removeComment(id: number){
        const exists = await this.prisma.comment.findUnique({where: {id}});
        if(!exists) throw new NotFoundException("Hiba: a comment nem található!");
        return await this.prisma.comment.delete({where: {id}});
    }
}
